//Class written by: Dev Patel

//For the composite pattern based on ISpecialEffect
public interface ISpecialEffect
{
    void Effect(ICharacter character);
}
