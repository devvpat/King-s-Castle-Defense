Dev Patel & TienYi Lee
GDIM 32/ICS 167
2/2/22
Playtest 1


How to play:
The game currently purely is played by click on buttons on the UI.
When playing, pirates will spawn on the left and try and attack your king on the right.
You can purchase defenders using coins that you gain passively and from killing enemies (pirates).

The game is currently singleplayer only where the player tries to defend the king.
In multiplayer, the other player will control pirate spawns (a script does this in singleplayer).

There is a lot of RNG in the game such as the enemy AI choosing who to attack and special effects 
happening randomly, and we did not have time to balance that aspect of the game, so it may be 
frustrating to play as winning is extremely luck reliant (especially hoping the enemy AI doesn't 
just charge your king while your troops are attacking someone else).