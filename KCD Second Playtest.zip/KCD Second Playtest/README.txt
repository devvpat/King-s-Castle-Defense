Dev Patel & TienYi Lee
GDIM 32/ICS 167
2/23/22
Playtest 2


Controls:
Navigating around the main menu is done purely through buttons clicks.
Once in-game (playing, not menu scene), one can click buttons or press the assosicated key (listed on the button) to interact with the button.
Press 'Escape' while in-game to pause/unpause the game.

How to play:
A how to play guide is included in the main menu (click on it to view it).
However, the basic gist is a game like Bloons Tower Defense/Plants vs. Zombies, but a very simplified version where one player's goal is to spawn knights using coins to defend the castle king, and the other's (or AI's in singleplayer) is to spawn pirates that will try and kill the castle king. To win, one team must defeat the other team's king; the pirate king always spawn after a certain amount of time (currently 60 seconds in both singleplayer and multiplayer, but this is still in testing).

Note for the AI, the pirate AI will target the closet enemy, and the knight AI will target the closest enemy to the castle king. Please let us know if this AI targetting seems fair (if that makes sense) or feels not too bad.

Also, if you have any feedback for the UI layout or general enjoyment you got out of the game and what could be improved/suggestions, please also let us know. Thank you in advance!

Final note, the singleplayer can actually be really difficult, and we haven't been able to spend much time making it easier, so don't feel bad if it seems impossible to win in singleplayer (we have only beat it once or twice ever). 